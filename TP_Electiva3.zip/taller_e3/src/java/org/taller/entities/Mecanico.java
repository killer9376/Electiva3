/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "mecanico")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mecanico.findAll", query = "SELECT m FROM Mecanico m")
    , @NamedQuery(name = "Mecanico.findByIdMecanico", query = "SELECT m FROM Mecanico m WHERE m.idMecanico = :idMecanico")
    , @NamedQuery(name = "Mecanico.findByNombreMeca", query = "SELECT m FROM Mecanico m WHERE m.nombreMeca = :nombreMeca")
    , @NamedQuery(name = "Mecanico.findByCiMeca", query = "SELECT m FROM Mecanico m WHERE m.ciMeca = :ciMeca")})
public class Mecanico implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "id_mecanico")
    private String idMecanico;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "nombre_meca")
    private String nombreMeca;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "ci_meca")
    private String ciMeca;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idMecanico")
    private Collection<OrdenTrabajo> ordenTrabajoCollection;

    public Mecanico() {
    }

    public Mecanico(String idMecanico) {
        this.idMecanico = idMecanico;
    }

    public Mecanico(String idMecanico, String nombreMeca, String ciMeca) {
        this.idMecanico = idMecanico;
        this.nombreMeca = nombreMeca;
        this.ciMeca = ciMeca;
    }

    public String getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(String idMecanico) {
        this.idMecanico = idMecanico;
    }

    public String getNombreMeca() {
        return nombreMeca;
    }

    public void setNombreMeca(String nombreMeca) {
        this.nombreMeca = nombreMeca;
    }

    public String getCiMeca() {
        return ciMeca;
    }

    public void setCiMeca(String ciMeca) {
        this.ciMeca = ciMeca;
    }

    @XmlTransient
    public Collection<OrdenTrabajo> getOrdenTrabajoCollection() {
        return ordenTrabajoCollection;
    }

    public void setOrdenTrabajoCollection(Collection<OrdenTrabajo> ordenTrabajoCollection) {
        this.ordenTrabajoCollection = ordenTrabajoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMecanico != null ? idMecanico.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mecanico)) {
            return false;
        }
        Mecanico other = (Mecanico) object;
        if ((this.idMecanico == null && other.idMecanico != null) || (this.idMecanico != null && !this.idMecanico.equals(other.idMecanico))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.Mecanico[ idMecanico=" + idMecanico + " ]";
    }
    
}
