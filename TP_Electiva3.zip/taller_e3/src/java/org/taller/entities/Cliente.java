/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "cliente")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c")
    , @NamedQuery(name = "Cliente.findByIdClie", query = "SELECT c FROM Cliente c WHERE c.idClie = :idClie")
    , @NamedQuery(name = "Cliente.findByDocClie", query = "SELECT c FROM Cliente c WHERE c.docClie = :docClie")
    , @NamedQuery(name = "Cliente.findByNombreClie", query = "SELECT c FROM Cliente c WHERE c.nombreClie = :nombreClie")
    , @NamedQuery(name = "Cliente.findByApellClie", query = "SELECT c FROM Cliente c WHERE c.apellClie = :apellClie")
    , @NamedQuery(name = "Cliente.findByDirecClie", query = "SELECT c FROM Cliente c WHERE c.direcClie = :direcClie")
    , @NamedQuery(name = "Cliente.findByTelefClie", query = "SELECT c FROM Cliente c WHERE c.telefClie = :telefClie")})
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_clie")
    private Integer idClie;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "doc_clie")
    private String docClie;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nombre_clie")
    private String nombreClie;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "apell_clie")
    private String apellClie;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "direc_clie")
    private String direcClie;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "telef_clie")
    private String telefClie;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idClie")
    private Collection<Vehiculo> vehiculoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idClie")
    private Collection<FacturaVentas> facturaVentasCollection;

    public Cliente() {
    }

    public Cliente(Integer idClie) {
        this.idClie = idClie;
    }

    public Cliente(Integer idClie, String docClie, String nombreClie, String apellClie, String direcClie, String telefClie) {
        this.idClie = idClie;
        this.docClie = docClie;
        this.nombreClie = nombreClie;
        this.apellClie = apellClie;
        this.direcClie = direcClie;
        this.telefClie = telefClie;
    }

    public Integer getIdClie() {
        return idClie;
    }

    public void setIdClie(Integer idClie) {
        this.idClie = idClie;
    }

    public String getDocClie() {
        return docClie;
    }

    public void setDocClie(String docClie) {
        this.docClie = docClie;
    }

    public String getNombreClie() {
        return nombreClie;
    }

    public void setNombreClie(String nombreClie) {
        this.nombreClie = nombreClie;
    }

    public String getApellClie() {
        return apellClie;
    }

    public void setApellClie(String apellClie) {
        this.apellClie = apellClie;
    }

    public String getDirecClie() {
        return direcClie;
    }

    public void setDirecClie(String direcClie) {
        this.direcClie = direcClie;
    }

    public String getTelefClie() {
        return telefClie;
    }

    public void setTelefClie(String telefClie) {
        this.telefClie = telefClie;
    }

    @XmlTransient
    public Collection<Vehiculo> getVehiculoCollection() {
        return vehiculoCollection;
    }

    public void setVehiculoCollection(Collection<Vehiculo> vehiculoCollection) {
        this.vehiculoCollection = vehiculoCollection;
    }

    @XmlTransient
    public Collection<FacturaVentas> getFacturaVentasCollection() {
        return facturaVentasCollection;
    }

    public void setFacturaVentasCollection(Collection<FacturaVentas> facturaVentasCollection) {
        this.facturaVentasCollection = facturaVentasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idClie != null ? idClie.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.idClie == null && other.idClie != null) || (this.idClie != null && !this.idClie.equals(other.idClie))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.Cliente[ idClie=" + idClie + " ]";
    }
    
}
