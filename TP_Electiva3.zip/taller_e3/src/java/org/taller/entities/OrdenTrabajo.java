/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "orden_trabajo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OrdenTrabajo.findAll", query = "SELECT o FROM OrdenTrabajo o")
    , @NamedQuery(name = "OrdenTrabajo.findByIdOrden", query = "SELECT o FROM OrdenTrabajo o WHERE o.idOrden = :idOrden")
    , @NamedQuery(name = "OrdenTrabajo.findByFechaEntrada", query = "SELECT o FROM OrdenTrabajo o WHERE o.fechaEntrada = :fechaEntrada")
    , @NamedQuery(name = "OrdenTrabajo.findByDiagnosticoOrden", query = "SELECT o FROM OrdenTrabajo o WHERE o.diagnosticoOrden = :diagnosticoOrden")})
public class OrdenTrabajo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_orden")
    private Integer idOrden;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_entrada")
    @Temporal(TemporalType.DATE)
    private Date fechaEntrada;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 500)
    @Column(name = "diagnostico_orden")
    private String diagnosticoOrden;
    @JoinColumn(name = "id_mecanico", referencedColumnName = "id_mecanico")
    @ManyToOne(optional = false)
    private Mecanico idMecanico;
    @JoinColumn(name = "id_vehi", referencedColumnName = "id_vehi")
    @ManyToOne(optional = false)
    private Vehiculo idVehi;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ordenTrabajo")
    private Collection<DetalleOrden> detalleOrdenCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idOrden")
    private Collection<FacturaVentas> facturaVentasCollection;

    public OrdenTrabajo() {
    }

    public OrdenTrabajo(Integer idOrden) {
        this.idOrden = idOrden;
    }

    public OrdenTrabajo(Integer idOrden, Date fechaEntrada, String diagnosticoOrden) {
        this.idOrden = idOrden;
        this.fechaEntrada = fechaEntrada;
        this.diagnosticoOrden = diagnosticoOrden;
    }

    public Integer getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(Integer idOrden) {
        this.idOrden = idOrden;
    }

    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public String getDiagnosticoOrden() {
        return diagnosticoOrden;
    }

    public void setDiagnosticoOrden(String diagnosticoOrden) {
        this.diagnosticoOrden = diagnosticoOrden;
    }

    public Mecanico getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(Mecanico idMecanico) {
        this.idMecanico = idMecanico;
    }

    public Vehiculo getIdVehi() {
        return idVehi;
    }

    public void setIdVehi(Vehiculo idVehi) {
        this.idVehi = idVehi;
    }

    @XmlTransient
    public Collection<DetalleOrden> getDetalleOrdenCollection() {
        return detalleOrdenCollection;
    }

    public void setDetalleOrdenCollection(Collection<DetalleOrden> detalleOrdenCollection) {
        this.detalleOrdenCollection = detalleOrdenCollection;
    }

    @XmlTransient
    public Collection<FacturaVentas> getFacturaVentasCollection() {
        return facturaVentasCollection;
    }

    public void setFacturaVentasCollection(Collection<FacturaVentas> facturaVentasCollection) {
        this.facturaVentasCollection = facturaVentasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idOrden != null ? idOrden.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrdenTrabajo)) {
            return false;
        }
        OrdenTrabajo other = (OrdenTrabajo) object;
        if ((this.idOrden == null && other.idOrden != null) || (this.idOrden != null && !this.idOrden.equals(other.idOrden))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.OrdenTrabajo[ idOrden=" + idOrden + " ]";
    }
    
}
