/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "articulo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Articulo.findAll", query = "SELECT a FROM Articulo a")
    , @NamedQuery(name = "Articulo.findByIdArt", query = "SELECT a FROM Articulo a WHERE a.idArt = :idArt")
    , @NamedQuery(name = "Articulo.findByDescArt", query = "SELECT a FROM Articulo a WHERE a.descArt = :descArt")
    , @NamedQuery(name = "Articulo.findByPrecioArt", query = "SELECT a FROM Articulo a WHERE a.precioArt = :precioArt")
    , @NamedQuery(name = "Articulo.findByTipoArt", query = "SELECT a FROM Articulo a WHERE a.tipoArt = :tipoArt")})
public class Articulo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_art")
    private Integer idArt;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "desc_art")
    private String descArt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio_art")
    private int precioArt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tipo_art")
    private boolean tipoArt;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idArt")
    private Collection<FacturaDetalle> facturaDetalleCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idArt")
    private Collection<DetalleOrden> detalleOrdenCollection;

    public Articulo() {
    }

    public Articulo(Integer idArt) {
        this.idArt = idArt;
    }

    public Articulo(Integer idArt, String descArt, int precioArt, boolean tipoArt) {
        this.idArt = idArt;
        this.descArt = descArt;
        this.precioArt = precioArt;
        this.tipoArt = tipoArt;
    }

    public Integer getIdArt() {
        return idArt;
    }

    public void setIdArt(Integer idArt) {
        this.idArt = idArt;
    }

    public String getDescArt() {
        return descArt;
    }

    public void setDescArt(String descArt) {
        this.descArt = descArt;
    }

    public int getPrecioArt() {
        return precioArt;
    }

    public void setPrecioArt(int precioArt) {
        this.precioArt = precioArt;
    }

    public boolean getTipoArt() {
        return tipoArt;
    }

    public void setTipoArt(boolean tipoArt) {
        this.tipoArt = tipoArt;
    }

    @XmlTransient
    public Collection<FacturaDetalle> getFacturaDetalleCollection() {
        return facturaDetalleCollection;
    }

    public void setFacturaDetalleCollection(Collection<FacturaDetalle> facturaDetalleCollection) {
        this.facturaDetalleCollection = facturaDetalleCollection;
    }

    @XmlTransient
    public Collection<DetalleOrden> getDetalleOrdenCollection() {
        return detalleOrdenCollection;
    }

    public void setDetalleOrdenCollection(Collection<DetalleOrden> detalleOrdenCollection) {
        this.detalleOrdenCollection = detalleOrdenCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idArt != null ? idArt.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Articulo)) {
            return false;
        }
        Articulo other = (Articulo) object;
        if ((this.idArt == null && other.idArt != null) || (this.idArt != null && !this.idArt.equals(other.idArt))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.Articulo[ idArt=" + idArt + " ]";
    }
    
}
