/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author User
 */
@Embeddable
public class FacturaDetallePK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "id_fven")
    private int idFven;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_fdet")
    private int idFdet;

    public FacturaDetallePK() {
    }

    public FacturaDetallePK(int idFven, int idFdet) {
        this.idFven = idFven;
        this.idFdet = idFdet;
    }

    public int getIdFven() {
        return idFven;
    }

    public void setIdFven(int idFven) {
        this.idFven = idFven;
    }

    public int getIdFdet() {
        return idFdet;
    }

    public void setIdFdet(int idFdet) {
        this.idFdet = idFdet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idFven;
        hash += (int) idFdet;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FacturaDetallePK)) {
            return false;
        }
        FacturaDetallePK other = (FacturaDetallePK) object;
        if (this.idFven != other.idFven) {
            return false;
        }
        if (this.idFdet != other.idFdet) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.FacturaDetallePK[ idFven=" + idFven + ", idFdet=" + idFdet + " ]";
    }
    
}
