/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "vehiculo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Vehiculo.findAll", query = "SELECT v FROM Vehiculo v")
    , @NamedQuery(name = "Vehiculo.findByIdVehi", query = "SELECT v FROM Vehiculo v WHERE v.idVehi = :idVehi")
    , @NamedQuery(name = "Vehiculo.findByMatriculaVehi", query = "SELECT v FROM Vehiculo v WHERE v.matriculaVehi = :matriculaVehi")
    , @NamedQuery(name = "Vehiculo.findByModeloVehi", query = "SELECT v FROM Vehiculo v WHERE v.modeloVehi = :modeloVehi")
    , @NamedQuery(name = "Vehiculo.findByColorVehi", query = "SELECT v FROM Vehiculo v WHERE v.colorVehi = :colorVehi")})
public class Vehiculo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_vehi")
    private Integer idVehi;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "matricula_vehi")
    private String matriculaVehi;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "modelo_vehi")
    private String modeloVehi;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "color_vehi")
    private String colorVehi;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idVehi")
    private Collection<OrdenTrabajo> ordenTrabajoCollection;
    @JoinColumn(name = "id_clie", referencedColumnName = "id_clie")
    @ManyToOne(optional = false)
    private Cliente idClie;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idVehi")
    private Collection<FacturaVentas> facturaVentasCollection;

    public Vehiculo() {
    }

    public Vehiculo(Integer idVehi) {
        this.idVehi = idVehi;
    }

    public Vehiculo(Integer idVehi, String matriculaVehi, String modeloVehi, String colorVehi) {
        this.idVehi = idVehi;
        this.matriculaVehi = matriculaVehi;
        this.modeloVehi = modeloVehi;
        this.colorVehi = colorVehi;
    }

    public Integer getIdVehi() {
        return idVehi;
    }

    public void setIdVehi(Integer idVehi) {
        this.idVehi = idVehi;
    }

    public String getMatriculaVehi() {
        return matriculaVehi;
    }

    public void setMatriculaVehi(String matriculaVehi) {
        this.matriculaVehi = matriculaVehi;
    }

    public String getModeloVehi() {
        return modeloVehi;
    }

    public void setModeloVehi(String modeloVehi) {
        this.modeloVehi = modeloVehi;
    }

    public String getColorVehi() {
        return colorVehi;
    }

    public void setColorVehi(String colorVehi) {
        this.colorVehi = colorVehi;
    }

    @XmlTransient
    public Collection<OrdenTrabajo> getOrdenTrabajoCollection() {
        return ordenTrabajoCollection;
    }

    public void setOrdenTrabajoCollection(Collection<OrdenTrabajo> ordenTrabajoCollection) {
        this.ordenTrabajoCollection = ordenTrabajoCollection;
    }

    public Cliente getIdClie() {
        return idClie;
    }

    public void setIdClie(Cliente idClie) {
        this.idClie = idClie;
    }

    @XmlTransient
    public Collection<FacturaVentas> getFacturaVentasCollection() {
        return facturaVentasCollection;
    }

    public void setFacturaVentasCollection(Collection<FacturaVentas> facturaVentasCollection) {
        this.facturaVentasCollection = facturaVentasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idVehi != null ? idVehi.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vehiculo)) {
            return false;
        }
        Vehiculo other = (Vehiculo) object;
        if ((this.idVehi == null && other.idVehi != null) || (this.idVehi != null && !this.idVehi.equals(other.idVehi))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.Vehiculo[ idVehi=" + idVehi + " ]";
    }
    
}
