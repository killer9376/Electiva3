/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "taller")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Taller.findAll", query = "SELECT t FROM Taller t")
    , @NamedQuery(name = "Taller.findByRucTaller", query = "SELECT t FROM Taller t WHERE t.rucTaller = :rucTaller")
    , @NamedQuery(name = "Taller.findByNombreTall", query = "SELECT t FROM Taller t WHERE t.nombreTall = :nombreTall")})
public class Taller implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ruc_taller")
    private Integer rucTaller;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nombre_tall")
    private String nombreTall;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "rucTaller")
    private Collection<FacturaVentas> facturaVentasCollection;

    public Taller() {
    }

    public Taller(Integer rucTaller) {
        this.rucTaller = rucTaller;
    }

    public Taller(Integer rucTaller, String nombreTall) {
        this.rucTaller = rucTaller;
        this.nombreTall = nombreTall;
    }

    public Integer getRucTaller() {
        return rucTaller;
    }

    public void setRucTaller(Integer rucTaller) {
        this.rucTaller = rucTaller;
    }

    public String getNombreTall() {
        return nombreTall;
    }

    public void setNombreTall(String nombreTall) {
        this.nombreTall = nombreTall;
    }

    @XmlTransient
    public Collection<FacturaVentas> getFacturaVentasCollection() {
        return facturaVentasCollection;
    }

    public void setFacturaVentasCollection(Collection<FacturaVentas> facturaVentasCollection) {
        this.facturaVentasCollection = facturaVentasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rucTaller != null ? rucTaller.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Taller)) {
            return false;
        }
        Taller other = (Taller) object;
        if ((this.rucTaller == null && other.rucTaller != null) || (this.rucTaller != null && !this.rucTaller.equals(other.rucTaller))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.Taller[ rucTaller=" + rucTaller + " ]";
    }
    
}
