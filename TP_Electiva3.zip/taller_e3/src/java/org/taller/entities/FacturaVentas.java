/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.taller.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "factura_ventas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FacturaVentas.findAll", query = "SELECT f FROM FacturaVentas f")
    , @NamedQuery(name = "FacturaVentas.findByIdFven", query = "SELECT f FROM FacturaVentas f WHERE f.idFven = :idFven")
    , @NamedQuery(name = "FacturaVentas.findByMontoTotal", query = "SELECT f FROM FacturaVentas f WHERE f.montoTotal = :montoTotal")})
public class FacturaVentas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_fven")
    private Integer idFven;
    @Basic(optional = false)
    @NotNull
    @Column(name = "monto_total")
    private int montoTotal;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "facturaVentas")
    private Collection<FacturaDetalle> facturaDetalleCollection;
    @JoinColumn(name = "id_clie", referencedColumnName = "id_clie")
    @ManyToOne(optional = false)
    private Cliente idClie;
    @JoinColumn(name = "id_orden", referencedColumnName = "id_orden")
    @ManyToOne(optional = false)
    private OrdenTrabajo idOrden;
    @JoinColumn(name = "ruc_taller", referencedColumnName = "ruc_taller")
    @ManyToOne(optional = false)
    private Taller rucTaller;
    @JoinColumn(name = "id_vehi", referencedColumnName = "id_vehi")
    @ManyToOne(optional = false)
    private Vehiculo idVehi;

    public FacturaVentas() {
    }

    public FacturaVentas(Integer idFven) {
        this.idFven = idFven;
    }

    public FacturaVentas(Integer idFven, int montoTotal) {
        this.idFven = idFven;
        this.montoTotal = montoTotal;
    }

    public Integer getIdFven() {
        return idFven;
    }

    public void setIdFven(Integer idFven) {
        this.idFven = idFven;
    }

    public int getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(int montoTotal) {
        this.montoTotal = montoTotal;
    }

    @XmlTransient
    public Collection<FacturaDetalle> getFacturaDetalleCollection() {
        return facturaDetalleCollection;
    }

    public void setFacturaDetalleCollection(Collection<FacturaDetalle> facturaDetalleCollection) {
        this.facturaDetalleCollection = facturaDetalleCollection;
    }

    public Cliente getIdClie() {
        return idClie;
    }

    public void setIdClie(Cliente idClie) {
        this.idClie = idClie;
    }

    public OrdenTrabajo getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(OrdenTrabajo idOrden) {
        this.idOrden = idOrden;
    }

    public Taller getRucTaller() {
        return rucTaller;
    }

    public void setRucTaller(Taller rucTaller) {
        this.rucTaller = rucTaller;
    }

    public Vehiculo getIdVehi() {
        return idVehi;
    }

    public void setIdVehi(Vehiculo idVehi) {
        this.idVehi = idVehi;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFven != null ? idFven.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FacturaVentas)) {
            return false;
        }
        FacturaVentas other = (FacturaVentas) object;
        if ((this.idFven == null && other.idFven != null) || (this.idFven != null && !this.idFven.equals(other.idFven))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.taller.entities.FacturaVentas[ idFven=" + idFven + " ]";
    }
    
}
